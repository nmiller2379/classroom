// created a var that holds my three choices of th game
var choose=["rock","paper","scissors"];
var a = document.querySelector("#rock");
var b = document.querySelector("#paper");
var c = document.querySelector("#scissors");
var d = document.querySelector("#playerText");
var e = document.querySelector("#computerText");
var f = document.querySelector("#resultText");
// below is two vars that is set to no initial value until in the code below
// when i use them in other functions
let playerChoice
let computerChoice 

// my randomizer function below
function roll(){
   return Math.floor(Math.random() * 3) + 1;
}
// random computer choice function 
function randomComputer() {
computerChoice = choose[roll()-1] 
// .textContent is used to log whatever to the webpage
   e.textContent="Computer: "+ " " + computerChoice;
}
// below is three different functions that are connected to 
// each button when clicked
function rock(){
  randomComputer();
     d.textContent="Player: " + "rock";
     playerChoice = "rock"
     if (computerChoice === playerChoice) {
       f.textContent = "~ DRAW ~"
    } else if (computerChoice==="scissors"){
        f.textContent = "WINNER WINNER"
    }else if(computerChoice==="paper"){
        f.textContent = "SORRY! TRY AGAIN"
}

}
function paper(){
     randomComputer();
     d.textContent="Player: " + " Paper";
     playerChoice = "paper"
     if (computerChoice === playerChoice) {
         f.textContent = "~ DRAW ~"
         } else if (computerChoice==="scissors"){
             f.textContent = "SORRY! TRY AGAIN"
         }else if(computerChoice==="rock"){
             f.textContent = "WINNER WINNER"
      }
     }
function scissors(){
    randomComputer();
    d.textContent="Player: " + " Scissors";
    playerChoice = "scissors"
     if (computerChoice === playerChoice) {
       f.textContent = "~ DRAW ~"
        } else if (computerChoice==="rock"){
            f.textContent = "SORRY! TRY AGAIN"
        }else if(computerChoice==="paper"){
            f.textContent = "WINNER WINNER"
    }
    }
    function reset(){
      window.location.reload()
    }



    
    


























// let choice = ["rock", "paper", "scissors"];


// function roll(){
//     return Math.floor(Math.random() * 3) + 1;
// }
// function random() {
//     for (let i = 1; i < choice.length; i++) {
//         document.getElementById("comp").innerHTML = choice[roll()];
//         return choice[roll()];
//     }
// }
// function rock(){
    
//     document.getElementById("game").innerHTML = "Rock";
// }
// function paper(){
//     document.getElementById("game").innerHTML = "Paper";
// }
// function scissors(){
//     document.getElementById("game").innerHTML = "Scissors";

//  }