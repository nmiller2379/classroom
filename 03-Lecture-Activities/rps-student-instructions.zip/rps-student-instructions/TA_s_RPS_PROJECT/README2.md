# Rock / Paper / Scissors Game
## Table of Contents
- [Introduction](#introduction)
- [Languages](#language)
- [Contributors](#contributors)
- [Support](#support)
- [Acknowledgements](#acknowledgements)
## Introduction
This neat game I designed is allowing the user to play an old school game against the computer! I also implemented the use of DOM manipulation when building this web app.
## Languages
- HTML
- CSS
- Javascript 

## Contributors
- Dev. Tonya Alexander
- Mr. Miller
- Ms. Harris
## Acknowledgments
Shout out to all new Developers in Persevere Co-hort#2. 
 