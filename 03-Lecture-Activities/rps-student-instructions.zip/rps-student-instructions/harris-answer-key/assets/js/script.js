const playerText = document.querySelector("#playerText");
const computerText = document.querySelector("#computerText");
const resultText = document.querySelector("#resultText");
const choiceBtns = document.querySelectorAll(".choiceBtn");
let player;
let computer;
let result;
let score;

function computerTurn() {
  const random = Math.floor(Math.random() * 5) + 1;
  switch (random) {
    case 1:
      computer = "💎";
      break;
    case 2:
      computer = "🧻";
      break;
    case 3:
      computer = "✂️";
      break;
    case 4:
      computer = "🦎";
      break;
    case 5:
      computer = "🖖🏽";
      break;
  }
}

function checkWinner() {
  if (player === computer) {
    return "Draw!";
  } else if ( (player === "🧻" && computer === "💎" ) || (player === "🧻" && computer === "🖖🏽") || (player === "💎" && computer === "✂️") || (player === "💎" && computer === "🦎" ) ||  (player === "✂️" && computer === "🧻" ) || (player === "✂️" && computer ===  "🦎" ) || (player === "🦎" && computer === "🖖🏽" ) || (player === "🦎" && computer === "🧻") || (player === "🖖🏽" && computer === "✂️") || (player === "🖖🏽" && computer === "💎" )) {
    return "You Win!";
  } else {
    return "You Lose!";
  }
}


choiceBtns.forEach((button) =>
  button.addEventListener("click", () => {
    player = button.textContent;
    computerTurn();
    playerText.textContent = `Player: ${player}`;
    computerText.textContent = `Computer: ${computer}`;
    resultText.textContent = checkWinner();
  })
);
