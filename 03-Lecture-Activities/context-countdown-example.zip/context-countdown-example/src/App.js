import './App.css';
import TimerProvider from './context/timerProvider';
import Timer from './components/TimerComponent/Timer'

function App() {
  return (
    <div className='App'>
    <TimerProvider>
      <Timer />
    </TimerProvider>
    </div>
  );
}

export default App;
