export const initialState = {
  timeLeft: {
    minutes: 25,
    seconds: "00", // Start as a string "00"
  },
  isRunning: false,
};

export default function timerReducer(state, action) {
  switch (action.type) {
    case "DECREMENT_SECOND":
      // If seconds are "00", switch to 59
      if (state.timeLeft.seconds === "00") {
        if (state.timeLeft.minutes === 0) {
          return { ...state, timeLeft: { minutes: 0, seconds: "00" }, isRunning: false }; // Timer finished
        }
        return {
          ...state,
          timeLeft: {
            minutes: state.timeLeft.minutes - 1,
            seconds: 59,
          },
        };
      }
      // If seconds are 0, switch back to string "00"
      if (state.timeLeft.seconds === 0) {
        if (state.timeLeft.minutes === 0) {
          return { ...state, timeLeft: { minutes: 0, seconds: "00" }, isRunning: false }; // Timer finished
        }
        return {
          ...state,
          timeLeft: {
            minutes: state.timeLeft.minutes - 1,
            seconds: 59,
          },
        };
      }
      // Decrement seconds normally
      return {
        ...state,
        timeLeft: {
          ...state.timeLeft,
          seconds: state.timeLeft.seconds - 1,
        },
      };
    case "START_CLOCK":
      return { ...state, isRunning: !state.isRunning };
    default:
      return state;
  }
}
