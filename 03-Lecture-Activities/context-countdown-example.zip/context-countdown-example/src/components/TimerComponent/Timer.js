import React, { useContext, useEffect } from 'react';
import TimerContext from '../../context/timerContext';
import Button from '../Button/Button';

export default function Timer() {
  const { state, dispatch } = useContext(TimerContext);

  useEffect(() => {
    let timerId;
    if (state.isRunning) {
      timerId = setTimeout(() => {
        dispatch({ type: 'DECREMENT_SECOND' });
      }, 1000);
    }
    return () => clearTimeout(timerId);
  }, [state.isRunning, state.timeLeft, dispatch]);

  return (
    <div>
      <p>
        {state.timeLeft.minutes}:
        {state.timeLeft.seconds === "00" ? "00" : state.timeLeft.seconds < 10 ? `0${state.timeLeft.seconds}` : state.timeLeft.seconds}
      </p>
      <Button onClick={() => dispatch({ type: 'START_CLOCK' })} isRunning={state.isRunning} />
    </div>
  );
}
