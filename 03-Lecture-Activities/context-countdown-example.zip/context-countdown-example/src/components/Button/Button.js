import React from 'react'

export default function Button({ onClick, isRunning }) {
  return (
    <button onClick={onClick}>
      {isRunning ? "Stop" : "Start"}
    </button>
  )
}
