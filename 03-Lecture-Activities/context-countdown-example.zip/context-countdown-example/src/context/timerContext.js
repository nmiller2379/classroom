import { createContext } from 'react';

const TimerContext = createContext();

export default TimerContext