import React, { useReducer } from 'react';
import timerReducer, { initialState } from "../reducers/timerReducer"
import TimerContext from './timerContext';

export default function TimerProvider({children}) {
    const [state, dispatch] = useReducer(timerReducer, initialState)
  return (
    <TimerContext.Provider value={{ state, dispatch}}>
        {children}
    </TimerContext.Provider>
  )
}
