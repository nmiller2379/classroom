### Practice Activities:

1. **Area Calculator Function: Return Early Pattern**
   - Write a function `calculateRectangleArea` that takes the length and width of a rectangle as parameters. Implement the "return early" pattern to check if either dimension is zero or negative, returning an appropriate message. Otherwise, calculate and return the area.

2. **Menu Selector Function: Dynamic Property Access**
   - Create a function `orderMenuItems` that takes a menu object representing items and their prices, as well as a menu item. Use dynamic property access within the function to retrun the selected item's price.

3. **Quiz Checker Function: Object as Lookup Table**
   - Write a function `checkQuizAnswer` that takes a question key and the user's answer as parameters. Use an object as a lookup table to store quiz questions and correct answers. Check if the user's answer matches the correct answer and return a Boolean value.

4. **Profile Updater Function: Object Manipulation**
   - Design a function `updateUserProfile` that takes a user profile object and allows the user to update their profile by entering a property name and a new value. Use dynamic property access within the function to apply the changes and return the updated profile.

5. **Weather Reporter Function: Nested Objects**
   - Write a function `getCityWeather` that takes a city name and a weather data object with information about different cities. Use nested object access to retrieve and return the temperature, humidity, and conditions for the specified city.
