// 1. Bracket Notation Exploration==============================================================
let myString = "JavaScript";

let char1 = myString[2]; // Access character at position 2
let char2 = myString[5]; // Access character at position 5
let char3 = myString[8]; // Access character at position 8

console.log(char1, char2, char3);

// 2. Array Manipulation==============================================================
let favoriteFruits = ["apple", "banana", "orange"];

// Add a new fruit to the end
favoriteFruits.push("kiwi");

// Remove the last fruit
let removedFruit = favoriteFruits.pop();

// Modify the first fruit
favoriteFruits[0] = "grape";

// Display the modified array
console.log(favoriteFruits);
console.log("Removed Fruit:", removedFruit);

// 3. Multi-Dimensional Array Puzzle==============================================================
let matrix = [
  [1, 2, 3],
  [4, 5, 6],
  [7, 8, 9],
];

// Access and display the value at the second row and third column
let element = matrix[1][2];
console.log("Element at (2, 3):", element);

// 4. String immutability==============================================================
function replaceVowelsWithX(inputString) {
  // Initialize an empty string to store the result
  let resultString = "";

  // Iterate through each character in the input string
  for (let i = 0; i < inputString.length; i++) {
    // Check if the current character is a vowel
    if (
      inputString[i] === "a" ||
      inputString[i] === "e" ||
      inputString[i] === "i" ||
      inputString[i] === "o" ||
      inputString[i] === "u" ||
      inputString[i] === "A" ||
      inputString[i] === "E" ||
      inputString[i] === "I" ||
      inputString[i] === "O" ||
      inputString[i] === "U"
    ) {
      // Append 'X' to the result string if it's a vowel
      resultString += "X";
    } else {
      // Otherwise, append the original character to the result string
      resultString += inputString[i];
    }
  }

  // Return the final result string
  return resultString;
}

// Example usage:
const inputString = "Hello, World!";
const result = replaceVowelsWithX(inputString);
console.log(result); // Output: "HXllX, WXrld!"

// 5. 2D Array================================================================================

function sumOfSubarrays(matrix) {
  // Create an array to return
  const sums = [];
  // Loop through outer array
  for (let i = 0; i < matrix.length; i++) {
    const row = matrix[i];
    let sum = 0;
    // Loop through inner array
    for (let j = 0; j < row.length; j++) {
      sum += row[j];
    }
    //   Push the sum into the return array
    sums.push(sum);
  }
  //   Return the return array
  return sums;
}

const MultiArray = [
  [1, 2, 3],
  [4, 5, 6],
  [7, 8, 9],
];

const sums = sumOfSubarrays(MultiArray);

console.log(sums);
// Output: [6, 15, 24]
