# String and array activities
These activities offer the chance to practice the stuff we covered in the lecture.

1. ## Bracket Notation Exploration
Description: Given a string, use bracket notation to access and display individual characters at various positions within the string.
Example: If the string is "JavaScript," retrieve and display the characters at positions 2, 5, and 8.

2. ## Array Manipulation Challenge:
Description: Create an array of your favorite fruits. Apply array manipulation techniques such as adding, removing, and modifying elements. Experiment with different methods like push, pop, shift, and unshift.

3. ## Multi-Dimensional Array Puzzle:
Description: Given a multi-dimensional array representing a 3x3 matrix, write JavaScript code to access and display specific elements within the matrix using nested indexes.
Example: Access and display the value at the second row and third column.
```
let matrix = [
    [11, 12, 13],
    [14, 15, 16],
    [17, 18, 19]
];

```

4. ## String Immutability Exercise:
Description: Choose a simple sentence or phrase. Use a loop to create a new string where all vowels are replaced with the letter 'X'.
Example: If the original sentence is "Hello, World!", the modified string would be "HXllX, WXrld!".

5. ## Sum of Subarrays
This problem is meant to stretch you a little bit. It does involve some concepts we haven't discussed yet. But see what you can do. If you get stuck, use your resources.

### Problem
Write a JavaScript function that takes a 2D array (matrix) as input and returns a new array where each element represents the sum of the numbers in the corresponding subarray.