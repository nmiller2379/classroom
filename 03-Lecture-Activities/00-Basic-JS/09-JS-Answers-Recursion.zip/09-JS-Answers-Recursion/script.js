// 1. Sum of Digits =============================================================================================
function sumOfDigits(n) {
    // Base case: If n is a single digit, return it
    if (n < 10) {
        return n;
    } else {
        // Recursive case: Sum the last digit and recurse with the rest of the digits. The modulus operator (%) is used in the sumOfDigits function to extract the last digit of the number n. The expression n % 10 gives the remainder when n is divided by 10, effectively isolating the last digit. This operation is used to obtain the rightmost digit of a number. The combination of n % 10 and Math.floor(n / 10) helps break down the original number n into its individual digits for the recursive summation in the sumOfDigits function. The recursive call processes each digit one by one until the base case is reached.
        return n % 10 + sumOfDigits(Math.floor(n / 10));
    }
}

// ANOTHER SOLUTION (Using substring())
function sumOfDigits1(n) {
    // Convert the number to a string
    const numStr = String(n);

    // Base case: If the string is empty, return 0
    if (numStr === "") {
        return 0;
    } else {
        // Recursive case: Convert the first character to a number and recurse with the rest of the string
        return Number(numStr[0]) + sumOfDigits(numStr.substring(1));
    }
}



// Example usage
console.log(sumOfDigits(123)); // Output: 6
console.log(sumOfDigits(9875)); // Output: 29

// 2. Power calculation ======================================================================================
function power(base, exponent) {
  // Base case: If the exponent is 0, return 1
  if (exponent === 0) {
    return 1;
  } else {
    // Recursive case: Multiply the base by the result of the recursive call with a decremented exponent
    return base * power(base, exponent - 1);
  }
}

// Example usage
console.log(power(2, 3)); // Output: 8
console.log(power(5, 0)); // Output: 1


// Example usage
console.log(power(2, 3)); // Output: 8
console.log(power(5, 0)); // Output: 1

// 3. String Reversal ====================================================================================
function reverseString(str) {
    // Base case: If the string is empty, return an empty string
    if (str.length === 0) {
        return "";
    } else {
        // Recursive case: Concatenate the last character and recurse with the rest of the string (What we need substring for)
        return str[str.length - 1] + reverseString(str.substring(0, str.length - 1));
    }
}

// Example usage
console.log(reverseString("hello")); // Output: olleh
console.log(reverseString("world")); // Output: dlrow