# JavaScript Basics Exercises
Working on your computer, create a directory for these exercises. Create a script.js file and an index.html file. Connect the two. Work in your script.js file to compelete these activities.

## Exercise 1: Variable Declaration

- Declare a variable named `age` and assign your age to it.
- Print the value of the variable to the console.

## Exercise 2: String Manipulation

- Declare two string variables, `firstName` and `lastName`.
- Concatenate them and store the result in a new variable called `fullName`.
- Print `fullName` to the console.

## Exercise 3: Block Scope Understanding

- Create a block using curly braces `{}`.
- Declare a variable `blockVariable` inside the block and assign a value.
- Attempt to access `blockVariable` outside the block and observe the result.

## Exercise 4: Mathematical Operations

- Declare two variables, `num1` and `num2`, with numeric values.
- Perform addition, subtraction, multiplication, and division.
- Print the results to the console.

## Exercise 5: Updated Constant Challenge

- Declare a constant variable named `gravit` and assign the value of Earth's gravitational acceleration (approximately 9.8 m/s²).
- Try to reassign a new value to `gravity` and notice the error.
- Print the gravitational acceleration value stored in `gravity` to the console.