// ---------- Variable Declaration
// Declare variable with my age (or desired age)
const age = 25;
console.log(age);

// --------- String Manipulation
// Declare first name
const firstName = "John";
// Declare last name
const lastName = "Doe";
// concatenate first and last together and store in fullName variable
const fullName = firstName + " " + lastName;
console.log(fullName);

// ---------- Block scope
{
    // Declare variable inside block
    const blockVariable = "I am inside the block.";
    console.log(blockVariable);
}
// Accessing outside the block will result in an error
// console.log(blockVariable);

// ----------- Mathematical Operations
const num1 = 10;
const num2 = 5;

const sum = num1 + num2;
const difference = num1 - num2;
const product = num1 * num2;
const quotient = num1 / num2;

console.log("Sum:", sum);
console.log("Difference:", difference);
console.log("Product:", product);
console.log("Quotient:", quotient);

// -------------- Updated Constant
const GRAVITY = 9.8;
// Attempting to reassign a new value will result in an error
// GRAVITY = 0;
console.log("Gravity on Earth:", GRAVITY + " m/s²");


