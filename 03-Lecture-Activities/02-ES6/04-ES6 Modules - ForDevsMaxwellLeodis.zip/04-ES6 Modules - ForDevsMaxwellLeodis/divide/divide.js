// Write a function that takes two numbers and returns the result of dividing one by the other.

// Export this module so that it can be used in your main module.