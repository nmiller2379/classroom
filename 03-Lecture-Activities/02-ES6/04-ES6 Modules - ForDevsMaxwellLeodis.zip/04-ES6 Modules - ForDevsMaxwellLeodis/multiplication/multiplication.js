// Write a function that multiplies two numbers and returns the result.

// Export the function so that it can be used in your main module.