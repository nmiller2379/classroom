// Write a function that takes two numbers and returns the result of dividing one by the other.
export default function divide(num1, num2) {
    return num1 / num2
}
// Export this module so that it can be used in your main module.