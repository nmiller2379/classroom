// Write a function that multiplies two numbers and returns the result.
export default function multiples(num1, num2) {
    return num1 * num2
}
// Export the function so that it can be used in your main module.