import multiples from "./multiplication/multiplication.js";
import divide from "./divide/divide.js";
import capLetter from "./capital/capital.js";

console.log(multiples(3, 3))
console.log(divide(10, 2))
console.log(capLetter("todd"))