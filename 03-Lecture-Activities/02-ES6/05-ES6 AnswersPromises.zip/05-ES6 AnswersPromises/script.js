// Task 1: Create a Promise
const myPromise = new Promise((resolve, reject) => {
    setTimeout(() => {
      const randomNumber = Math.random();
      if (randomNumber > 0.5) {
        resolve('Success: ' + randomNumber);
      } else {
        reject('Error: ' + randomNumber);
      }
    }, 2000); // Simulating an asynchronous operation with a delay of 2 seconds
  });
  
  // Task 2: Handle Promise
  myPromise
    .then((result) => {
      console.log(result); // Output if resolved
    })
    .catch((error) => {
      console.error(error); // Output if rejected
    });
  
  // Task 3: Error Handling
  myPromise.catch((error) => {
    console.error(error); // Output if rejected
  });
  
  // Task 4: Chaining Promises (Optional)
  const anotherPromise = new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve('Another Promise Resolved');
    }, 1500); // Simulating another asynchronous operation with a delay of 1.5 seconds
  });
  
  anotherPromise
    .then((result) => {
      console.log(result); // Output if resolved
    })
    .catch((error) => {
      console.error(error); // Output if rejected
  });
  
