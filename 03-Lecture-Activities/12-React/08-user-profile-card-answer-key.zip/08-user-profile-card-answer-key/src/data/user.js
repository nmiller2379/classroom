import avatar from '../assets/avatar11.jpg'

const user = {
  name: "John Doe",
  bio: "Full Stack Developer",
  profilePicture: avatar,
};

export default user
