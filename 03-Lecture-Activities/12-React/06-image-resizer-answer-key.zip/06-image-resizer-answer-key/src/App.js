import './App.css';
import ImageResizer from './components/ImageResizer/ImageResizer';

function App() {
  return (
    <ImageResizer />
  );
}

export default App;
