import "./App.css";
import RecipeContainer from "./components/RecipeContainer/RecipeContainer";

function App() {
  return (
    <div className="App">
      <RecipeContainer />
    </div>
  );
}

export default App;
