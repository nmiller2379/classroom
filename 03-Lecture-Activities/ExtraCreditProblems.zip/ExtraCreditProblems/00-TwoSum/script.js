function twoSum(nums, target) {
    // Your code here
}

// DO NOT CHANGE THE CODE BELOW THIS LINE
if (typeof module !== "undefined" && module.exports) {
    module.exports = twoSum;
} else {
    window.twoSum = twoSum;
}