function getRow(rowIndex) {
  // Your code here
}

// DO NOT CHANGE THE CODE BELOW THIS LINE
if (typeof module !== "undefined" && module.exports) {
  module.exports = getRow;
} else {
  window.getRow = getRow;
}
