function findDisappearedNumbers(nums) {
  // Your code here
}

// DO NOT CHANGE THE CODE BELOW THIS LINE
if (typeof module !== "undefined" && module.exports) {
  module.exports = findDisappearedNumbers;
} else {
  window.findDisappearedNumbers = findDisappearedNumbers;
}
