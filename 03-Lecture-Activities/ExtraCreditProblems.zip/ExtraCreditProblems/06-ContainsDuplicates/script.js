function containsDuplicate(nums, k) {
    // Your code here
}

// DO NOT CHANGE THE CODE BELOW THIS LINE
if (typeof module !== "undefined" && module.exports) {
    module.exports = containsDuplicate;
} else {
    window.containsDuplicate = containsDuplicate;
}