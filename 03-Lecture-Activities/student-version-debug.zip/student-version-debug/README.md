# Debugging

You will be debugging the following assignment!.

## User Story
It seems Groot tried to help me fix up this webpage. The problem is, the poor guy didn't check for the mistakes he made. I don't have much time to go through and fix what he did or even check the any of the files and folders. Would you please go through and fix it. It was working fine until he tried to help. Check out the video inside of the assets folder to see what the application is supposed to do.

```
1. It is done when the correct files are in the correct locations.
2. It is done when all bugs/errors in the HTML, CSS, and JavaScript files are moved.
3. It is done when the application can function correctly in the browser.
4. It is done when you add comments to the code explaining the error you found and how you corrected it.
```

## A Little Extra
If you finish early and have time, you could add some functionality from more animals. Choose from the list below, or use them all:

* 🐒
* 🐅
* 🐎
* 🦙
* 🐧



## Conclusion
Good luck!