**Title: Largest Power**

**Problem Statement**
Given a positive integer `N`, return the largest integer `k` such that `3^k < N`.

**Example 1:**
- Input: `N = 3`
- Output: `0`

**Example 2:**
- Input: `N = 4`
- Output: `1`

**Example 3:**
- Input: `N = 81`
- Output: `3`

-----
You may assume that the input to your function is always a positive integer greater than 0.