# Extra Credit Problems

These 10 problems are designed to give you additinal practice with problem solving and algorithmic thinking. They are generally of a complexity level similar to the `Intermediate Algorithm Scripting` sub-module you just completed.

## Credit

Each successfully completed problem (all tests passing) is worth 1 point, for a total of 10 extra credit points for the full set. NOTE: The grader will work from a different testing suite.

## Due Date

The problem set is due no later than the end of the day on May 20. Good luck and enjoy the challenge!
