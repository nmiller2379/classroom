# Project: Password Generator

## Introduction
You will be given this project to create the logic, styling, and skeleton of a password generator. You may have fun with this and create it into something, but need the follow the parameters of the project.

## User Story
```
1. It is done when I have a fully functioning password generator.
2. It is done when I can choose uppercase letters, lowercase letters, numbers, AND/OR symbols for my password.
3. It is done when I can choose between having 8 to 124 characters in my password.
4. It should have the error handling to show that it cannot generate a password without the user choosing at least one character choice.
5. It must have the password appear on the page.
6. You cannot use alert boxes for this.
```

## Application Examples

![password-gen](./assets/images/password-ex-1.jpg)
![password-gen-2](./assets/images/password-ex-2.jpg)


## Conclusion
This will be due by April 7th, 2023 EOD.