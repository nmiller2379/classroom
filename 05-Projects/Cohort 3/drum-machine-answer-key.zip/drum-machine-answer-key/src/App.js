import './App.css';
import DrumMachine from './components/DrumMachine/DrumMachine';

function App() {
  return (
    <div className="App">
      <DrumMachine />
    </div>
  );
}

export default App;
