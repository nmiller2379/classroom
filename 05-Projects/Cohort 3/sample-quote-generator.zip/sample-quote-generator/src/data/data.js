const data = [
    { quote: "Just win, baby", author: "Al Davis" },
    { quote: "Winning isn't everything, it's the only thing", author: "Vince Lombardi" },
    { quote: "I don't know if I agree with all this crap about winning.", author: "Mr. Miller"}
]

export default data