import './App.css';
import QuoteWrapper from './components/QuoteWrapper/QuoteWrapper';

function App() {
  return (
    <QuoteWrapper />
  );
}

export default App;
