export default function randomNumber(num) {
    return Math.floor(Math.random() * num)
}