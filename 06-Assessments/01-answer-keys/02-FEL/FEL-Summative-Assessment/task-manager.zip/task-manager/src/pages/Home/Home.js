import React from 'react'
import { useNavigate } from "react-router";

export default function Home() {
  const navigate = useNavigate();
  return (
    <div>
      <h1 id='title'>TaskPro</h1>
      <p class='description'>Are you struggling to keep track of your ever-growing to-do list? Do deadlines often sneak up on you, causing unnecessary stress and missed opportunities? Look no further than TaskPro, the groundbreaking software application designed to revolutionize the way you manage your tasks.</p>
      <p class='description'>TaskPro is your personal task management companion, empowering you to take control of your productivity like never before. With its intuitive interface and powerful features, this app allows you to input tasks, important details, and set deadlines effortlessly. Stay organized and focused as you tackle your responsibilities with ease.</p>
      <button id='create' onClick={() => navigate("/form")}>Create a task</button>
    </div>
  )
}
