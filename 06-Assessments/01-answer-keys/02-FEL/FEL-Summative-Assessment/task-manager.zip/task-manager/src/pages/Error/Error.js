import React from 'react'

export default function Error() {
  return (
    <div>
      The page you're looking for does not exist
    </div>
  )
}
