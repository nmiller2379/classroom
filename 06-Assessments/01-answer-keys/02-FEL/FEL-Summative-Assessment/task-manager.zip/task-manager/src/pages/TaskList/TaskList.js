import React, { useContext } from 'react';
import { TaskContext } from '../../context/taskContext';
import { COMPLETE_TASK } from '../../reducer/taskReducer';
import { DELETE_TASK } from '../../reducer/taskReducer';
import { useNavigate } from "react-router";


export default function TaskList() {
  const { state, dispatch } = useContext(TaskContext)
  const navigate = useNavigate();

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const options = { month: 'long', day: 'numeric', year: 'numeric' };
    return date.toLocaleDateString('en-US', options);
  }
  

  const handleDone = (e) => {
    console.log(state)
    let idValue = parseInt(e.target.value)
    dispatch({ type: COMPLETE_TASK, payload: idValue})
  }

  const handleDelete = (e) => {
    console.log(state)
    let idValue = parseInt(e.target.value)
    dispatch({ type: DELETE_TASK, payload: idValue})
  }

  return (
    <div>
      {state.tasks.map((task) => {
        return (<div key={task.id} className={task.isComplete ?  "red" : 'standard'}>
          <h3>Task: {task.name}</h3> 
          <p><b>Task description:</b> {task.description}</p>
          <p><b>Due date:</b> {formatDate(task.date)}</p>
          <button onClick={handleDone} value={task.id}>Done</button>
          <button onClick={handleDelete} value={task.id}>Delete</button>
          <hr />
        </div>)})}
        <button onClick={() =>{navigate("/form")} }>Add another task</button>
    </div>
  )
}
