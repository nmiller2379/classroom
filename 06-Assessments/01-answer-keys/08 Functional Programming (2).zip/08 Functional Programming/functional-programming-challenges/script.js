// The global variable
const bookList = [
  "The Hound of the Baskervilles",
  "On The Electrodynamics of Moving Bodies",
  "Philosophiæ Naturalis Principia Mathematica",
  "Disquisitiones Arithmeticae",
];

// Change code below this line
function add(arr, bookName) {
    let newArr = [...arr]
    newArr.push(bookName);
    return newArr;

    // OR LIKE THIS
    // function add(list, bookName) {
    //     return [...bookList, bookName];
    // }

  // Change code above this line
}

// Change code below this line
function remove(arr, bookName) {
    let newArr = [...arr];
    if (newArr.indexOf(bookName) >= 0) {
        newArr.splice(newArr.indexOf(bookName), 1)
        return newArr;

        // OR LIKE THIS
        // function remove(list, bookName) {
        //     return list.filter(book => book !== bookName);
        // }


    // Change code above this line
  }
}

var newBookList = add(bookList, 'A Brief History of Time');
var newerBookList = remove(bookList, 'On The Electrodynamics of Moving Bodies');
var newestBookList = remove(add(bookList, 'A Brief History of Time'), 'On The Electrodynamics of Moving Bodies');

console.log(bookList);


Array.prototype.myMap = function(callback) {
    const newArray = [];
    // Only change code below this line
    for (let i = 0; i < this.length; i++) {
        newArray.push(callback(this[i], i, this));
    }

    // OR LIKE THIS
    // this.forEach((element, index, originalArray) =>{
    //     newArray.push(callback(element, index, originalArray))
    // });

    // Only change code above this line
    return newArray;
  };