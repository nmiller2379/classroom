// forEach

// ForEach will call a funtion provided callback function one time on each time in an array. It will not return anything. In that way, it's most similar to a for loop.
const myArr = [1, 2, 3, 4, 5]

myArr.forEach(e => console.log(e)) 

console.log(multiplyNums(myArr))

/*=============================================================*/

// Array.prototype.map()
// The map() method creates a new array populated with the results of calling a provided function on every element in the calling array.

// 1. Make a new array
// 2. New array will be filled up with whatever results from calling a function that we provide on each element in the array.

const anotherArray = [10, 20, 30, 40, 50]

// return a value into a new array. Map is doing this for us behind the scenes 
// const AnotherNewArray = []

function multiplyNums(arr) {
 return arr.map((e) => e * 10);
}

const myResult = multiplyNums(anotherArray)

// console.log(myResult)

const arrayOfNumbers = [10, 20, 30, 40, 50]

const result = arrayOfNumbers.map(number => number + 5)

console.log(result)

const ArrayOfObjs = [
    {firstName: "Todd", lastName: "Smith"},
    {firstName: "Jane", lastName: "Doe"},
    {firstName: "Phil", lastName: "Collins"},
    {firstName: "Jean", lastName: "Simmons"},
]

function findFirstNames(arr) {
    return arr.map(item => item.firstName)
}

console.log(findFirstNames(ArrayOfObjs))

// Given an array of objects withfirstNameast name properties, return an array of objects with a name property whose value includesfirstNameast names.

function createNamesObj(arr) {
    const mappedArr = arr.map((item => {
        const tempObj = {
            name: []
        }
        tempObj.name.push(item.firstName, item.lastName)
        return tempObj
    }))
   return mappedArr.map(item => {
    const finalObj = {
    name: item.name.join(" ")
   }
   return finalObj
})  
}

console.log(createNamesObj(ArrayOfObjs))

// function createNamesObj(arr) {
//   return arr.map((item) => ({ name: item.firstName + " " + item.lastName }));
// }

// console.log(createNamesObj(ArrayOfObjs))

/*=============================================================*/

const anotherNumbersArray = [1, 2, 3, 4, 5, 6]

function findEvens(arr) {
    return arr.filter(item => item % 2 === 0)
}

// console.log(findEvens(anotherNumbersArray))

const anotherArrayOfObjs = [
    {firstName: "Todd", lastName: "Smith", gradeAverage: "70"},
    {firstName: "Jane", lastName: "Doe", gradeAverage: "88"},
    {firstName: "Todd", lastName: "Collins", gradeAverage: "92"},
    {firstName: "Jean", lastName: "Simmons", gradeAverage: "74"},
]

function findNames(arr) {
    const tempVariable = arr.filter(item => item.gradeAverage > 79)
    arr.forEach(item => console.log(item))
    return tempVariable
}

// console.log(findNames(anotherArrayOfObjs))

/*=============================================================*/


// The reduce() method executes a user-supplied "reducer" callback function on each element of the array, in order, passing in the return value from the calculation on the preceding element. The final result of running the reducer across all elements of the array is a single value.

// 1. Just like map, or filter reduce is going to call a function on each element in an array.
// 2. But unlike map and filter, the callback function is a reducer function and has to follow a certain syntax. The reducer function must have at least two parameters. Those are accumulator and currentValue.
// 3. The reducer function is called on each element in the array and essentailly adds the current value to the accumulator.
// 4. Another way that reduce is more complicated than the others is it can take multiple arguments in its call. But reduce is expecting at least one other argument. That is the initial value.
// 5. An additional way that reduce is different from map and filter is that won't necessarily return an array. It will return a single value, which can be an object, an array, a string, a number.

const yetAnotherNumbersArray = [27, 19, 15, 5]

const sum = yetAnotherNumbersArray.reduce((accumulator, currentValue) => accumulator * currentValue, 1)

// console.log(sum)

const duplicateNumbers = [2, 5, 7, 5, 12, 9, 7, 5, 4, 3, 2, 4, 15]

function removeDuplicates(arr) {
    let reducedArray = arr.reduce((accumulator, currentValue) => {
        if (!accumulator.includes(currentValue)) {
            return [...accumulator, currentValue]
        }
        return accumulator
    }, []) 
    return reducedArray
}

// console.log(removeDuplicates(duplicateNumbers))


function noDuplicates(arr) {
    return arr.reduce((accumulator, currentValue) => {
        if(accumulator.indexOf(currentValue) === -1) {
            accumulator.push(currentValue)
        }
        return accumulator
    }, [])
}

// console.log(noDuplicates(duplicateNumbers))

// function testFunc() {
//  return "I'm returning stuff"
// }

// console.log(testFunc())

// FUNCTIONS AND PURE FUNCTIONS
let num = 1
function addNums(number) {
    return number += 10
}

const returnValue = addNums(num)
console.log(addNums(num))
console.log(num)

console.log(returnValue)

// console.log(addNums())
// console.log(addNums())

/*=============================================================*/

// DOT AND BRACKET NOTATION
const exampleArrayOfObjects = [
    {"first Name": "Todd", lastName: "Smith", gradeAverage: "70"},
    {"first Name": "Jane", lastName: "Doe", gradeAverage: "88"},
    {"first Name": "Todd", lastName: "Collins", gradeAverage: "92"},
    {"first Name": "Jean", lastName: "Simmons", gradeAverage: "74"},
]

function findName(arr, prop){
    return arr[2][prop]
} 

console.log(findName(exampleArrayOfObjects, "first Name"))

// console.log(exampleArrayOfObjects[2][property])

// The main factor that will help you make your decision is the key of the property you want to access. If it is a static key, use Dot Notation. But if it is a dynamic key (evaluated from an expression during runtime), use Bracket Notation.


/*=============================================================*/

// DOM Manipulation

/* A good key to DOM manipulation is good file structure. This means you're adhering to clean coding standards to not only help you, but others who are handling your code. */

// const grandparent = document.getElementById("grandparent-id");
const grandparent = document.querySelector("#grandparent-id");
// const parents = document.getElementsByClassName("parent");
const parents = document.querySelectorAll(".parent");
const children = document.querySelector(".child")

/*At the top of any JavaScript file should be the placement of your variables. Here these allow you to manipulate your HTML page and thus manipulate the DOM. 

REMEMBER: querySelector and querySelectorAll are more common now thanks to ES6, but getElementsbyClassName and getElementById work equally well.

Next, a function will be created to show how the DOM is being manipulated:*/

function changeColor(element) {
    element.style.backgroundColor = "#555"
}

function changeText(element){
    element.textContent = "Waaaaazzzzzaaaaup?"
}

// The above function can be written to give specific elements certain characteristics in different ways such as:

// granparent.style.backgroundColor = "#555";
// grandparent.textContent = "Wazzzzzaaaaaaup?";

// We can apply the functionality to the given variables like:

changeColor(grandparent);
changeText(children);

/*=============================================================*/

// DOM and Functions

// Top of the order, first we put our variable. So we want to focus on button 2.
const btn2 = document.querySelector(".btn-2");

// Functions are next! We want to give the button functionality and control it via the function.
function graveOffense(){
    alert("I was clicked! How dare you, sir!");
}

// Finally, we call the functions and/or put our button events here.
btn2.addEventListener("click", graveOffense);