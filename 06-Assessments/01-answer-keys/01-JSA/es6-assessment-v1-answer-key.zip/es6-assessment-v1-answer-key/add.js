export default function addNums(a, b) {
  return a + b;
}
