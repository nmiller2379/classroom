function strStr(haystack, needle) {
  // Your code here
}

// DO NOT CHANGE THE CODE BELOW THIS LINE
if (typeof module !== "undefined" && module.exports) {
  module.exports = strStr;
} else {
  window.strStr = strStr;
}
