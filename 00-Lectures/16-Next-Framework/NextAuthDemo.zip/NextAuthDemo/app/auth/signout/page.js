export default function SignOut() {
  return (
    <div>
      <h1>You have successfully signed out!</h1>
      <p>We hope to see you again soon.</p>
      <a href="/">Return to Home</a> {/* Link to return to homepage */}
    </div>
  );
}

