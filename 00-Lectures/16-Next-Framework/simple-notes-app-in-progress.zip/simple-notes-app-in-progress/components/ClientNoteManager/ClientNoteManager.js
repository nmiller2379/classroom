'use client';
import { useState } from 'react';
import NotesList from "../NoteList/NoteList";
import Form from "../Form/Form";

export default function ClientNoteManager({ initialNotes }) {
    const [notes, setNotes] = useState(initialNotes);

    const onNoteUpdate = (updatedNote) => {
        setNotes((prevNotes) => {
            const noteIndex = prevNotes.findIndex(note => note._id === updatedNote._id);
            if (noteIndex !== -1) {
                const newNotes = [...prevNotes];
                newNotes[noteIndex] = updatedNote;
                return newNotes;
            }
            return [...prevNotes, updatedNote];
        });
    };

    return (
        <div>
            <NotesList initialNotes={notes} onNoteUpdate={onNoteUpdate} />
            <Form onNoteUpdate={onNoteUpdate} />
        </div>
    );
}
