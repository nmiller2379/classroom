'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';

export default function NotesList({ initialNotes }) {
        const [notes, setNotes] = useState([]);

    useEffect(() => {
        if (initialNotes) {
            setNotes(initialNotes);
        }
    }, [initialNotes]); // React to changes in initialNotes

    // const handleNoteUpdate = (updatedNote) => {
    //     setNotes((prevNotes) => {
    //         const noteIndex = prevNotes.findIndex(note => note._id === updatedNote._id);
    //         if (noteIndex !== -1) {
    //             const newNotes = [...prevNotes];
    //             newNotes[noteIndex] = updatedNote;
    //             return newNotes;
    //         }
    //         return [...prevNotes, updatedNote];
    //     });
    // };

    return (
        <ul>
            {notes.map(note => (
                <Link href={`/notes/${note._id}`}><li key={note._id}>{note.title}</li></Link>
            ))}
        </ul>
    );
}
