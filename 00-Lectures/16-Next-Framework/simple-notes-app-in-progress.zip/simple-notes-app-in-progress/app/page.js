import ClientNoteManager from "../components/ClientNoteManager/ClientNoteManager";

async function fetchNotes() {
  const res = await fetch('http://localhost:3000/api/notes', {
    cache: 'no-store', // Ensure fresh data on each request
  });
  if (!res.ok) {
    throw new Error('Failed to fetch notes');
  }
  return res.json();
}
export default async function Home() {
  const initialNotes = await fetchNotes();
  console.log(initialNotes)
  return (
    <div>
      <h1>Notes</h1>
      <ClientNoteManager initialNotes={initialNotes} />
    </div>
  );
}

