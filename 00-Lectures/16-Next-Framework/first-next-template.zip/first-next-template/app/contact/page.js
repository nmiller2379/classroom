export default function Contact() {
  return (
    <div>
      <h1>Contact Us</h1>
      <p>Feel free to contact us at contact@example.com.</p>
    </div>
  );
}

