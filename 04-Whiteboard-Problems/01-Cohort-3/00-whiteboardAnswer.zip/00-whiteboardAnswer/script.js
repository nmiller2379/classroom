// Susie wants to write a function to greet anyone who calls the function with thier name. She wants them to receive the message "Hello " and their name. However, she is in love with Johnny, so when she greets Johnny, she wants him to receive the message "Hello, my love!" Among other problems for Susie, she doesn't know how to use JavScript or how functions work. Please help her out.

// RESTATE THE PROBLEM
// Write a function that takes a string as an argument and returns "Hello, my love" if the string is "Johnny" and "Hello string" otherwise.

// ANALYSIS
// Output: A string, either "Hello Mr. Miller" or "Hello, my love!"
// Input: A string representing hello and a name or Hello, my love! 
// Constraints: Only Johny can get the "Hello, my love!" message; Any name other than "Johnny" must receive a string of "Hello name"; must write a function and put logic in a function; 
// Examples: "Mike" should return "Hello Mike"; "Carl" should return "Hello Carl"; "Johnny" should return "Hello, my love!"
// Edge cases: 7 should return "Hello 7"? true should return "Hello true"; "Johny" should return "Hello Johny" 
// Questions this raises: Will the input always be a string? Do I have to handle for invalid inputs such as other data types or no input?

// ALGORITHM
// 1. Define a function called greet that takes name as a parameter
// 2. Check if the value of name === Johnny
// 3. Generate the greeting message: If name === "Johnny" the message should say "Hello, my love!" Otherwise it should say "Hello " followed by the input name
// 4. Return the message based on the condition.

// PSEUDOCODE
// FUNCTION greet
    // Parameters: (name)
    // Body: IF name === "Johnny"
                // RETURN "Hello, my love!"
            // ELSE
                // RETURN "Hello " + name

// Let's try this with a couple of our examples and make sure we think it works.
// Let's call the function with "Fred" for name. greet("Fred"). Fred does not equal "Johnny" so the ELSE code block should execute so it should return "Hello Fred" So far so good. If we call it with "Johnny" for name, Johnny does equal Johnny so the IF block should execute. It looks like a good solution. Let's code it out.

// PSEUDOCODE
// FUNCTION greet
    // Parameters: (name)
    // Body: IF name === "Johnny"
                // RETURN "Hello, my love!"
            // ELSE
                // RETURN "Hello " + name

function greet(name) {
  if (name === "Johnny") {
    return "Hello, my love!";
  } else {
    return "Hello " + name;
  }
}

console.log(greet("Johnny"))
console.log(greet("Bill"))

// Looks good.

