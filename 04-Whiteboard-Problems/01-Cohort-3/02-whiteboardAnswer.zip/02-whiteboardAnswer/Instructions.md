## Count the Pairs
Write a function that takes an array of unique integers and returns the count of the pairs of elements in the array with a difference of 3. The function should return the count. 