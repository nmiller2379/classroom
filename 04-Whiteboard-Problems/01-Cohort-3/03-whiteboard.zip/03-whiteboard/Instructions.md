# Multiple of Index

Given an array of integers, return a new array consisting of elements that are multiples of their own index in the given array.
