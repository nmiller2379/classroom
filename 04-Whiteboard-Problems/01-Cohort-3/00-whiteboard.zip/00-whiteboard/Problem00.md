# Susie's function
Susie wants to write a function to greet anyone who calls the function. She wants them to receive the message "Hello " and their name. However, she is in love with Johnny, so when she greets Johnny, she wants him to receive the message "Hello, my love!" Among other problems for Susie, she doesn't know how to use JavScript or how functions work. Please help her out.

